package com.cg.ticketing.client;

import java.util.Scanner;

import com.cg.ticketing.services.TicketingServices;
import com.cg.ticketing.services.TicketingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		int choice;
		Scanner sc=new Scanner(System.in);
		TicketingServices ticketingServices=new TicketingServicesImpl();
	while(true) {
		System.out.println("Enter Your Choice");
		System.out.println("Press 1 For Book");
		System.out.println("Press 2 For Cancel Ticket");
		choice=sc.nextInt();
		switch(choice){
		case 1:
		}
	}

	}
}
