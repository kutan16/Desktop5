package com.cg.ticketing.daoservices;


import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.UnReservedTicket;
import com.cg.ticketing.util.TrainTicketingDBUtil;

public class UnreservedBookingImpl implements UnReservedBookingDAO{

	@Override
	public UnReservedTicket save(UnReservedTicket ticketId) {
		ticketId.setTicketId(TrainTicketingDBUtil.getTicket_ID_COUNTER());
		TrainTicketingDBUtil.unreservedService.put(ticketId.getTicketId(), ticketId);
		return ticketId;
	}

	@Override
	public UnReservedTicket findOne(UnReservedTicket ticketId) {
		return TrainTicketingDBUtil.unreservedService.get(ticketId);
	}
	@Override
	public UnReservedTicket delete(UnReservedTicket ticketId) {
		TrainTicketingDBUtil.service.get(ticketId);
		ticketId.setTicketId(TrainTicketingDBUtil.getTicket_ID_COUNTER()-1);		
		return ticketId;
	}
	
	
}
