package com.cg.ticketing.exception;

public class InvalidTicketIdException extends Exception{
	
}
