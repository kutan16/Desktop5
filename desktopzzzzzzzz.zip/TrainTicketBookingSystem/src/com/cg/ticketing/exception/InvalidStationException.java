package com.cg.ticketing.exception;

public class InvalidStationException extends Exception{

}
